#include <string>;
#include <iostream>;
#include <vector>;
#include <fstream>;
#include <time.h>;

using namespace std;

int main()
{
	int card [52];

	string StringArray [4];
	StringArray[0] = "Hearts";
	StringArray[1] = "Spades";
	StringArray[2] = "Clubs";
	StringArray[3] = "Diamonds";

	string CardIntToString [53];

	string CardArray [53];
			for(int J = 1;J < 53; J++){
				card[J]=J;
				CardIntToString[J] = to_string(card[J]);
				if(J<14){
				CardArray[J] = CardIntToString[J] + " of " + StringArray[0] + "\n";
				} else if(J<27){
					CardArray[J] = CardIntToString[J-13] + " of " + StringArray[1] + "\n";
					} else if(J<40){
						CardArray[J] = CardIntToString[J-26] + " of " + StringArray[2] + "\n";
						} else if(J<53){
							CardArray[J] = CardIntToString[J-39] + " of " + StringArray[3] + "\n";
						}
				}
	
	
	system("pause");
	for(int o=0;o<53;o++){
	cout << CardArray[o];
	}
	system("pause");

	system("pause");
	
return 0;
}